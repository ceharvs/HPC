#ifndef _FOR_SUBS_H_
#define _FOR_SUBS_H_

extern void work(int *,int *);

#endif

