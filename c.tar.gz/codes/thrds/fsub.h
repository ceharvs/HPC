#ifndef _FSUB_H_
#define _FSUB_H_

extern void fmandel_(int *i0,int *i1,int *j0,int *j1,int *nx,int *ny,int *itmx,
                    double *x0,double *y0,double *dx,double *dy,int *img);
                  

#endif
