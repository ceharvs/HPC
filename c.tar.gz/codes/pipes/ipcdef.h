#ifndef _MY_IPCDEF_H_
#define _MY_IPCDEF_H_

#define FIFONAME "myfifo"
#define FIFOMODE 0666
#define BUFSIZE  512
#define NMAX     100

#endif

